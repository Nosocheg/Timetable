-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 07 2022 г., 12:31
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `schedule`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `userName` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `userName`, `password`) VALUES
(1, 'admin', '12345678');

-- --------------------------------------------------------

--
-- Структура таблицы `tblaud`
--

CREATE TABLE `tblaud` (
  `id` int(11) NOT NULL,
  `num` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tblaud`
--

INSERT INTO `tblaud` (`id`, `num`) VALUES
(1, '111/2'),
(2, '112/1'),
(3, '17и'),
(4, '103'),
(12, '105');

-- --------------------------------------------------------

--
-- Структура таблицы `tbldow`
--

CREATE TABLE `tbldow` (
  `id` int(11) NOT NULL,
  `dow` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbldow`
--

INSERT INTO `tbldow` (`id`, `dow`) VALUES
(1, 'Понедельник'),
(2, 'Вторник'),
(3, 'Среда'),
(4, 'Четверг'),
(5, 'Пятница'),
(6, 'Суббота');

-- --------------------------------------------------------

--
-- Структура таблицы `tblgroups`
--

CREATE TABLE `tblgroups` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'LIST',
  `kurs_id` int(11) DEFAULT NULL COMMENT 'FK'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tblgroups`
--

INSERT INTO `tblgroups` (`id`, `name`, `kurs_id`) VALUES
(1, 'ЭЖ-555', 1),
(2, 'Х-212', 2),
(3, 'Х-213', 2),
(4, 'Х-214', 3),
(5, 'Х-2113', 4),
(6, 'Х-2114', 5),
(7, 'Х-221', 1),
(8, 'Х-224', 2),
(9, 'Х-201', 1),
(11, 'ЭЖ-777', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `tblkurs`
--

CREATE TABLE `tblkurs` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'LIST',
  `faculty` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Корпоративные информационные системы'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tblkurs`
--

INSERT INTO `tblkurs` (`id`, `name`, `faculty`) VALUES
(1, '1 курс', 'Корпоративные информационные системы'),
(2, '2 курс', 'Корпоративные информационные системы'),
(3, '3 курс', 'Корпоративные информационные системы'),
(4, '4 курс', 'Корпоративные информационные системы'),
(5, '5 курс + магистры', 'Корпоративные информационные системы'),
(6, 'аспиранты', 'Корпоративные информационные системы'),
(7, 'программирование python fullstek', 'Корпоративные информационные системы');

-- --------------------------------------------------------

--
-- Структура таблицы `tblprepod`
--

CREATE TABLE `tblprepod` (
  `id` int(11) NOT NULL,
  `fio` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tblprepod`
--

INSERT INTO `tblprepod` (`id`, `fio`) VALUES
(1, 'Казакова Алена Сергеевна'),
(2, 'Апраксин А.С.'),
(3, 'Толстой А.Н.'),
(4, 'Лермонтов И.М.'),
(5, 'Достоевский Сергей Петрович');

-- --------------------------------------------------------

--
-- Структура таблицы `tbltime`
--

CREATE TABLE `tbltime` (
  `id` int(11) NOT NULL,
  `timew` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tbltime`
--

INSERT INTO `tbltime` (`id`, `timew`) VALUES
(1, '08.00-09.35'),
(2, '09.45-11.20'),
(3, '11.50-13.25'),
(4, '13.35-15.10'),
(5, '15.20-16.55'),
(6, '17.05-18.40');

-- --------------------------------------------------------

--
-- Структура таблицы `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `firstName` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emailId` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobileNumber` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userPassword` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `isActive` int(1) DEFAULT NULL,
  `lastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tblusers`
--

INSERT INTO `tblusers` (`id`, `firstName`, `lastName`, `emailId`, `mobileNumber`, `userPassword`, `regDate`, `isActive`, `lastUpdationDate`) VALUES
(3, 'Иван', 'Петров', 'user@test.ru', '1111111112', '12345678', '2021-12-25 14:57:43', 1, '2022-02-15 14:18:01'),
(4, 'Тута', 'Ларсен', 'abc@xyz.ru', '1234567908', '12345678', '2018-12-25 15:43:33', 1, '2021-12-25 15:48:18');

-- --------------------------------------------------------

--
-- Структура таблицы `tblworks`
--

CREATE TABLE `tblworks` (
  `id` int(11) NOT NULL,
  `dow_id` int(11) DEFAULT NULL COMMENT 'День недели',
  `time_id` int(11) DEFAULT NULL COMMENT 'Время предмета',
  `name` varchar(500) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Инфо - предмет',
  `group_id` int(11) DEFAULT NULL COMMENT 'Группа',
  `aud_id` int(11) DEFAULT NULL COMMENT 'Аудитория',
  `prepod_id` int(11) DEFAULT NULL COMMENT 'Преподаватель'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tblworks`
--

INSERT INTO `tblworks` (`id`, `dow_id`, `time_id`, `name`, `group_id`, `aud_id`, `prepod_id`) VALUES
(1, 1, 1, 'Прикладная математика', 1, 1, 1),
(2, 1, 2, 'Физика элементарных частиц', 1, 3, 2),
(3, 1, 3, 'Новейшая История России', 1, 4, 3),
(5, 2, 1, 'Право', 2, 2, 3);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tblaud`
--
ALTER TABLE `tblaud`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tbldow`
--
ALTER TABLE `tbldow`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tblgroups`
--
ALTER TABLE `tblgroups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_kurs_id` (`kurs_id`);

--
-- Индексы таблицы `tblkurs`
--
ALTER TABLE `tblkurs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tblprepod`
--
ALTER TABLE `tblprepod`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tbltime`
--
ALTER TABLE `tbltime`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tblworks`
--
ALTER TABLE `tblworks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_dow_id` (`dow_id`),
  ADD KEY `fk_time_id` (`time_id`),
  ADD KEY `fk_group_id` (`group_id`),
  ADD KEY `fk_aud_id` (`aud_id`),
  ADD KEY `fk_prepod_id` (`prepod_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `tblaud`
--
ALTER TABLE `tblaud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `tbldow`
--
ALTER TABLE `tbldow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `tblgroups`
--
ALTER TABLE `tblgroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `tblkurs`
--
ALTER TABLE `tblkurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `tblprepod`
--
ALTER TABLE `tblprepod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `tbltime`
--
ALTER TABLE `tbltime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `tblworks`
--
ALTER TABLE `tblworks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `tblgroups`
--
ALTER TABLE `tblgroups`
  ADD CONSTRAINT `fk_kurs_id` FOREIGN KEY (`kurs_id`) REFERENCES `tblkurs` (`id`);

--
-- Ограничения внешнего ключа таблицы `tblworks`
--
ALTER TABLE `tblworks`
  ADD CONSTRAINT `fk_aud_id` FOREIGN KEY (`aud_id`) REFERENCES `tblaud` (`id`),
  ADD CONSTRAINT `fk_dow_id` FOREIGN KEY (`dow_id`) REFERENCES `tbldow` (`id`),
  ADD CONSTRAINT `fk_group_id` FOREIGN KEY (`group_id`) REFERENCES `tblgroups` (`id`),
  ADD CONSTRAINT `fk_prepod_id` FOREIGN KEY (`prepod_id`) REFERENCES `tblprepod` (`id`),
  ADD CONSTRAINT `fk_time_id` FOREIGN KEY (`time_id`) REFERENCES `tbltime` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
