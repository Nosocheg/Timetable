<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
Class ManageAuds_Model extends CI_Model{
	//---------------load-----------------------
	public function getaudsdetails(){
		$query=$this->db->select('num,id')
		              ->get('tblaud');
	        return $query->result();      
}

//---------------delete---------------------
 public function deleteaud($uid){
$sql_query=$this->db->where('id', $uid)
                ->delete('tblaud');
            }

//---------------add-----------------------
public function createaud($num) {
		$data = array(
               'num' => $num
            );
		$sql_query=$this->db->insert('tblaud', $data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Аудитория успешно добавлена.');
			redirect('admin/Manage_Auds');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Auds');
		}
	}
//------------get id----------------------
 public function getauddata($fid){
		$query=$this->db->select('`num`, `id`')
					  ->where('id',$fid)
		              ->get('tblaud');
		        return $query->result();  
	}
//------------edit------------------------
public function editaud($fid,$num) {
		$data = array(
               'num' => $num
            );
		$sql_query=$this->db->where('id',$fid)
							->update('tblaud',$data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Аудитория успешно обновлена.');
			redirect('admin/Manage_Auds');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Auds');
		}
	}
}