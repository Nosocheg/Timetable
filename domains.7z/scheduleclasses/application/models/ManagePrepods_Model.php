<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
Class ManagePrepods_Model extends CI_Model{
	//---------------load-----------------------
	public function getprepodsdetails(){
		$query=$this->db->select('fio,id')
		              ->get('tblprepod');
	        return $query->result();      
}

//---------------delete---------------------
 public function deleteprepod($uid){
$sql_query=$this->db->where('id', $uid)
                ->delete('tblprepod');
            }

//---------------add-----------------------
public function createprepod($fio) {
		$data = array(
               'fio' => $fio
            );
		$sql_query=$this->db->insert('tblprepod', $data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Преподаватель успешно добавлен.');
			redirect('admin/Manage_Prepods');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Prepods');
		}
	}
//------------get id----------------------
 public function getprepoddata($fid){
		$query=$this->db->select('`fio`, `id`')
					  ->where('id',$fid)
		              ->get('tblprepod');
		        return $query->result();  
	}
//------------edit------------------------
public function editprepod($fid,$fio) {
		$data = array(
               'fio' => $fio
            );
		$sql_query=$this->db->where('id',$fid)
							->update('tblprepod',$data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Преподаватель успешно обновлен.');
			redirect('admin/Manage_Prepods');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Prepods');
		}
	}
}