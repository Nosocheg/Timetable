<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
Class ManageGroups_Model extends CI_Model{
	//---------------load-----------------------
	public function getgroupsdetails(){
		$sql = "SELECT g.name, k.name as kname, g.id
     			FROM tblgroups AS g LEFT JOIN tblkurs AS k ON g.kurs_id = k.id";
		$query = $this->db->query($sql);
	        return $query->result();      
}
//------------load kurs---------------------
public function getkursdetails(){
		$query=$this->db->select('name,faculty,id')
		              ->get('tblkurs');
	        return $query->result();      
}
//---------------delete---------------------
 public function deletegroups($uid){
$sql_query=$this->db->where('id', $uid)
                ->delete('tblgroups');
            }

//---------------add-----------------------
public function creategroups($name,$kurs_id) {
		$data = array(
               'name' => $name,
			   'kurs_id' => $kurs_id
            );
		$sql_query=$this->db->insert('tblgroups', $data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Группа успешно добавлена.');
			redirect('admin/Manage_Groups');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Groups');
		}
	}
//------------get id----------------------
 public function getgroupsdata($fid){
		$sql = "SELECT g.name, k.id as kid, k.name as kname, g.id
     			FROM tblgroups AS g LEFT JOIN tblkurs AS k ON g.kurs_id = k.id WHERE g.id = ".$fid;
		$query = $this->db->query($sql);
		        return $query->result();  
	}
//------------edit------------------------
public function editgroups($fid,$name,$kurs_id) {
		$data = array(
               'name' => $name,
			   'kurs_id' => $kurs_id
            );
		$sql_query=$this->db->where('id',$fid)
							->update('tblgroups',$data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Группа успешно обновлена.');
			redirect('admin/Manage_Groups');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Groups');
		}
	}
}