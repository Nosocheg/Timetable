<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
Class ManageWorks_Model extends CI_Model{
	//---------------load-----------------------
	public function getworksdetails(){
		$sql = "SELECT d.dow as ddow, t.timew as ttime, w.name as wname, g.name as gname, a.num as anum, p.fio as pfio, w.id 
     			FROM tblworks AS w LEFT JOIN tbldow AS d ON w.dow_id = d.id 
				LEFT JOIN tbltime AS t ON w.time_id = t.id LEFT JOIN tblgroups AS g ON w.group_id = g.id 
				LEFT JOIN tblaud AS a ON w.aud_id = a.id LEFT JOIN tblprepod AS p ON w.prepod_id = p.id";
		$query = $this->db->query($sql);
	        return $query->result();      
}
//------------load dows---------------------
public function getdowsdetails(){
		$query=$this->db->select('dow,id')
		              ->get('tbldow');
	        return $query->result();      
}
//------------load times---------------------
public function gettimesdetails(){
		$query=$this->db->select('timew,id')
		              ->get('tbltime');
	        return $query->result();      
}
//------------load groups---------------------
public function getgroupsdetails(){
		$query=$this->db->select('name,id')
		              ->get('tblgroups');
	        return $query->result();      
}
//------------load auds---------------------
public function getaudsdetails(){
		$query=$this->db->select('num,id')
		              ->get('tblaud');
	        return $query->result();      
}
//------------load prepods---------------------
public function getprepodsdetails(){
		$query=$this->db->select('fio,id')
		              ->get('tblprepod');
	        return $query->result();      
}
//---------------delete---------------------
 public function deleteworks($uid){
$sql_query=$this->db->where('id', $uid)
                ->delete('tblworks');
            }

//---------------add-----------------------
public function createworks($dow_id,$time_id,$name,$group_id,$aud_id,$prepod_id) {
		$data = array(
			    'dow_id' => $dow_id,
				'time_id' => $time_id,
				'name' => $name,
				'group_id' => $group_id,
				'aud_id' => $aud_id,
				'prepod_id' => $prepod_id
            );
		$sql_query=$this->db->insert('tblworks', $data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Расписание успешно добавлено.');
			redirect('admin/Manage_Works');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Works');
		}
	}
//------------get id----------------------
 public function getworksdata($fid){
		$sql = "SELECT d.dow as ddow, w.dow_id, t.timew as ttime, w.time_id, w.name as wname,  
		        g.name as gname, w.group_id, a.num as anum, w.aud_id, p.fio as pfio, w.prepod_id, w.id 
     			FROM tblworks AS w LEFT JOIN tbldow AS d ON w.dow_id = d.id 
				LEFT JOIN tbltime AS t ON w.time_id = t.id LEFT JOIN tblgroups AS g ON w.group_id = g.id 
				LEFT JOIN tblaud AS a ON w.aud_id = a.id LEFT JOIN tblprepod AS p ON w.prepod_id = p.id WHERE w.id = ".$fid;
		$query = $this->db->query($sql);
		        return $query->result();  
	}
//------------edit------------------------
public function editworks($fid,$dow_id,$time_id,$name,$group_id,$aud_id,$prepod_id) {
		$data = array(
               'dow_id' => $dow_id,
				'time_id' => $time_id,
				'name' => $name,
				'group_id' => $group_id,
				'aud_id' => $aud_id,
				'prepod_id' => $prepod_id
            );
		$sql_query=$this->db->where('id',$fid)
							->update('tblworks',$data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Расписание успешно обновлено.');
			redirect('admin/Manage_Works');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Works');
		}
	}
}