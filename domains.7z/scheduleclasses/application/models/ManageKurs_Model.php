<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
Class ManageKurs_Model extends CI_Model{
	//---------------load-----------------------
	public function getkursdetails(){
		$query=$this->db->select('name,faculty,id')
		              ->get('tblkurs');
	        return $query->result();      
}

//---------------delete---------------------
 public function deletekurs($uid){
$sql_query=$this->db->where('id', $uid)
                ->delete('tblkurs');
            }

//---------------add-----------------------
public function createkurs($name) {
		$data = array(
               'name' => $name
            );
		$sql_query=$this->db->insert('tblkurs', $data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Курс успешно добавлен.');
			redirect('admin/Manage_Kurs');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Kurs');
		}
	}
//------------get id----------------------
 public function getkursdata($fid){
		$query=$this->db->select('`name`, `id`')
					  ->where('id',$fid)
		              ->get('tblkurs');
		        return $query->result();  
	}
//------------edit------------------------
public function editkurs($fid,$name) {
		$data = array(
               'name' => $name
            );
		$sql_query=$this->db->where('id',$fid)
							->update('tblkurs',$data); 
		if($sql_query){
			$this->session->set_flashdata('success', 'Курс успешно обновлен.');
			redirect('admin/Manage_Kurs');
		} else {
			$this->session->set_flashdata('error', 'Что-то пошло не так. Ошибка!');
			redirect('admin/Manage_Kurs');
		}
	}
}