<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
Class UserWorks_Model extends CI_Model{
	//------------load groups---------------------
	public function getgroupsdetails(){
			$query=$this->db->select('name,id')
						  ->get('tblgroups');
				return $query->result();      
	}
	//------------load auds---------------------
	public function getaudsdetails(){
			$query=$this->db->select('num,id')
						  ->get('tblaud');
				return $query->result();      
	}
	//------------load prepods---------------------
	public function getprepodsdetails(){
			$query=$this->db->select('fio,id')
						  ->get('tblprepod');
				return $query->result();      
	}
	//-------------search------------------------
	public function searchworks($group_id,$aud_id,$prepod_id){
			if($group_id!='') { $filter[] =  "w.group_id = ".$group_id; }
			if ($aud_id!='') { $filter[] =  "w.aud_id = ".$aud_id; } 
			if ($prepod_id!='') { $filter[] =  "w.prepod_id = ".$prepod_id; }
			$sql = "SELECT d.dow as ddow, t.timew as ttime, w.name as wname, g.name as gname, a.num as anum, p.fio as pfio, w.id 
					FROM tblworks AS w LEFT JOIN tbldow AS d ON w.dow_id = d.id 
					LEFT JOIN tbltime AS t ON w.time_id = t.id LEFT JOIN tblgroups AS g ON w.group_id = g.id 
					LEFT JOIN tblaud AS a ON w.aud_id = a.id LEFT JOIN tblprepod AS p ON w.prepod_id = p.id WHERE ".implode(' AND ', $filter);
			$query = $this->db->query($sql);
				return $query->result();      
	}
}