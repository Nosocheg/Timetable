<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Resetpass extends CI_Controller {
	
public function index(){
	$this->form_validation->set_rules('emailid','Email id','required|valid_email');
 	$this->form_validation->set_rules('password','Password','required|min_length[6]');
	$this->form_validation->set_rules('confirmpassword','Confirm Password','required|min_length[6]|matches[password]');
  if($this->form_validation->run()){
	$emailid=$this->input->post('emailid');
	$password=$this->input->post('password');
	$this->load->model('Signup_Model');
	if ($this->Signup_Model->email_exists($emailid)) {
	$this->Signup_Model->passupdate($emailid,$password);
	} else {
	$this->session->set_flashdata('error', 'Проверьте правильность ввода Email id.Ошибка!');
	redirect('user/Resetpass');
	}
   } else {
	$this->load->view('user/passreset');
  }
 }
}