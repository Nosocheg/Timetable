<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Manage_Kurs extends CI_Controller {
	function __construct(){
	parent::__construct();
	if(! $this->session->userdata('adid'))
	redirect('admin/login');
	}
	//--------------load--------------------
	public function index(){
	$this->load->model('ManageKurs_Model');
	$user=$this->ManageKurs_Model->getkursdetails();
	$this->load->view('admin/manage_kurs',['userdetails'=>$user]);
	}
    //---------------add--------------------
	public function createkurs() {
		$this->form_validation->set_rules('name','Курс','required');
		if($this->form_validation->run()){
    		$name=$this->input->post('name');
			$this->load->model('ManageKurs_Model');
			$this->ManageKurs_Model->createkurs($name);
		} else {
			$this->load->view('admin/createkurs');
		}
	}
	//---------------edit--------------------
	public function editkurs($fid){
		$this->form_validation->set_rules('name','Курс','required');
		if($this->form_validation->run()){
			$name=$this->input->post('name');
			$this->load->model('ManageKurs_Model');
			$this->ManageKurs_Model->editkurs($fid,$name);
		} else {
			$this->load->model('ManageKurs_Model');
			$udetail=$this->ManageKurs_Model->getkursdata($fid);
			$this->load->view('admin/editkurs',['familyd'=>$udetail]);
		}
	}
	//-----------------del------------------
	public function deletekurs($uid)
	{
	$this->load->model('ManageKurs_Model');
	$this->ManageKurs_Model->deletekurs($uid);
	$this->session->set_flashdata('success', 'Курс успешно удален!');
	redirect('admin/manage_Kurs');
	}
}