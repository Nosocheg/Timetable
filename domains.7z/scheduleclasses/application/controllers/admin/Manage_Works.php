<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Manage_Works extends CI_Controller {
	function __construct(){
	parent::__construct();
	if(! $this->session->userdata('adid'))
	redirect('admin/login');
	}
	//--------------load--------------------
	public function index(){
	$this->load->model('ManageWorks_Model');
	$user=$this->ManageWorks_Model->getworksdetails();
	$this->load->view('admin/manage_works',['userdetails'=>$user]);
	}
    //---------------add--------------------
	public function createworks() {
		$this->form_validation->set_rules('name','Предмет','required');
		if($this->form_validation->run()){
			$dow_id=$this->input->post('dow_id');
			$time_id=$this->input->post('time_id');
    		$name=$this->input->post('name');
			$group_id=$this->input->post('group_id');
			$aud_id=$this->input->post('aud_id');
			$prepod_id=$this->input->post('prepod_id');
			$this->load->model('ManageWorks_Model');
			$this->ManageWorks_Model->createworks($dow_id,$time_id,$name,$group_id,$aud_id,$prepod_id);
		} else {
			//-------------load id-------------
			$this->load->model('ManageWorks_Model');
			$dows=$this->ManageWorks_Model->getdowsdetails();
			$times=$this->ManageWorks_Model->gettimesdetails();
			$groups=$this->ManageWorks_Model->getgroupsdetails();
			$auds=$this->ManageWorks_Model->getaudsdetails();
			$prepods=$this->ManageWorks_Model->getprepodsdetails();
			$this->load->view('admin/createworks',['dowsdetails'=>$dows,'timesdetails'=>$times,'groupsdetails'=>$groups,'audsdetails'=>$auds,'prepodsdetails'=>$prepods]);
		}
	}
	//---------------edit--------------------
	public function editworks($fid){
		$this->form_validation->set_rules('name','Предмет','required');
		if($this->form_validation->run()){
			$dow_id=$this->input->post('dow_id');
			$time_id=$this->input->post('time_id');
    		$name=$this->input->post('name');
			$group_id=$this->input->post('group_id');
			$aud_id=$this->input->post('aud_id');
			$prepod_id=$this->input->post('prepod_id');
			$this->load->model('ManageWorks_Model');
			$this->ManageWorks_Model->editworks($fid,$dow_id,$time_id,$name,$group_id,$aud_id,$prepod_id);
		} else {
			$this->load->model('ManageWorks_Model');
			$udetail=$this->ManageWorks_Model->getworksdata($fid);
			$dows=$this->ManageWorks_Model->getdowsdetails();
			$times=$this->ManageWorks_Model->gettimesdetails();
			$groups=$this->ManageWorks_Model->getgroupsdetails();
			$auds=$this->ManageWorks_Model->getaudsdetails();
			$prepods=$this->ManageWorks_Model->getprepodsdetails();
			$this->load->view('admin/editworks',['familyd'=>$udetail,'dowsdetails'=>$dows,'timesdetails'=>$times,'groupsdetails'=>$groups,'audsdetails'=>$auds,'prepodsdetails'=>$prepods]);
		}
	}
	//-----------------del------------------
	public function deleteworks($uid)
	{
	$this->load->model('ManageWorks_Model');
	$this->ManageWorks_Model->deleteworks($uid);
	$this->session->set_flashdata('success', 'Предмет успешно удален!');
	redirect('admin/manage_works');
	}
}