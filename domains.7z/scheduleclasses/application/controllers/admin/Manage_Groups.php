<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Manage_Groups extends CI_Controller {
	function __construct(){
	parent::__construct();
	if(! $this->session->userdata('adid'))
	redirect('admin/login');
	}
	//--------------load--------------------
	public function index(){
	$this->load->model('ManageGroups_Model');
	$user=$this->ManageGroups_Model->getgroupsdetails();
	$this->load->view('admin/manage_groups',['userdetails'=>$user]);
	
	}
		
    //---------------add--------------------
	public function creategroups() {
		$this->form_validation->set_rules('name','Группа','required');
		if($this->form_validation->run()){
    		$name=$this->input->post('name');
			$kurs_id=$this->input->post('kurs_id');
			$this->load->model('ManageGroups_Model');
			$this->ManageGroups_Model->creategroups($name,$kurs_id);
		} else {
			//-------------load kurs id-------------
			$this->load->model('ManageGroups_Model');
			$stores=$this->ManageGroups_Model->getkursdetails();
			$this->load->view('admin/creategroups',['kursdetails'=>$stores]);
		}
	}
	//---------------edit--------------------
	public function editgroups($fid){
		
		$this->form_validation->set_rules('name','Группа','required');
		if($this->form_validation->run()){
			$name=$this->input->post('name');
			$kurs_id=$this->input->post('kurs_id');
			$this->load->model('ManageGroups_Model');
			$this->ManageGroups_Model->editgroups($fid,$name,$kurs_id);
		} else {
			$this->load->model('ManageGroups_Model');
			$udetail=$this->ManageGroups_Model->getgroupsdata($fid);
			$stores=$this->ManageGroups_Model->getkursdetails();
			$this->load->view('admin/editgroups',['familyd'=>$udetail,'kursdetails'=>$stores]);
		}
	}
	//-----------------del------------------
	public function deletegroups($uid)
	{
	$this->load->model('ManageGroups_Model');
	$this->ManageGroups_Model->deletegroups($uid);
	$this->session->set_flashdata('success', 'Группа успешно удален!');
	redirect('admin/manage_groups');
	}
}