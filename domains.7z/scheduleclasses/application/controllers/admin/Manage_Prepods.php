<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Manage_Prepods extends CI_Controller {
	function __construct(){
	parent::__construct();
	if(! $this->session->userdata('adid'))
	redirect('admin/login');
	}
	//--------------load--------------------
	public function index(){
	$this->load->model('ManagePrepods_Model');
	$user=$this->ManagePrepods_Model->getprepodsdetails();
	$this->load->view('admin/manage_prepods',['userdetails'=>$user]);
	}
    //---------------add--------------------
	public function createprepod() {
		$this->form_validation->set_rules('fio','Преподаватель','required');
		if($this->form_validation->run()){
    		$fio=$this->input->post('fio');
			$this->load->model('ManagePrepods_Model');
			$this->ManagePrepods_Model->createprepod($fio);
		} else {
			$this->load->view('admin/createprepod');
		}
	}
	//---------------edit--------------------
	public function editprepod($fid){
		$this->form_validation->set_rules('fio','Преподаватель','required');
		if($this->form_validation->run()){
			$fio=$this->input->post('fio');
			$this->load->model('ManagePrepods_Model');
			$this->ManagePrepods_Model->editprepod($fid,$fio);
		} else {
			$this->load->model('ManagePrepods_Model');
			$udetail=$this->ManagePrepods_Model->getprepoddata($fid);
			$this->load->view('admin/editprepod',['familyd'=>$udetail]);
		}
	}
	//-----------------del------------------
	public function deleteprepod($uid)
	{
	$this->load->model('ManagePrepods_Model');
	$this->ManagePrepods_Model->deleteprepod($uid);
	$this->session->set_flashdata('success', 'Преподаватель успешно удален!');
	redirect('admin/manage_prepods');
	}
}