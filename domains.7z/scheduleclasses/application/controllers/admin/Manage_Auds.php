<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Manage_Auds extends CI_Controller {
	function __construct(){
	parent::__construct();
	if(! $this->session->userdata('adid'))
	redirect('admin/login');
	}
	//--------------load--------------------
	public function index(){
	$this->load->model('ManageAuds_Model');
	$user=$this->ManageAuds_Model->getaudsdetails();
	$this->load->view('admin/manage_auds',['userdetails'=>$user]);
	}
    //---------------add--------------------
	public function createaud() {
		$this->form_validation->set_rules('num','Аудитория','required');
		if($this->form_validation->run()){
    		$num=$this->input->post('num');
			$this->load->model('ManageAuds_Model');
			$this->ManageAuds_Model->createaud($num);
		} else {
			$this->load->view('admin/createaud');
		}
	}
	//---------------edit--------------------
	public function editaud($fid){
		$this->form_validation->set_rules('num','Аудитория','required');
		if($this->form_validation->run()){
			$num=$this->input->post('num');
			$this->load->model('ManageAuds_Model');
			$this->ManageAuds_Model->editaud($fid,$num);
		} else {
			$this->load->model('ManageAuds_Model');
			$udetail=$this->ManageAuds_Model->getauddata($fid);
			$this->load->view('admin/editaud',['familyd'=>$udetail]);
		}
	}
	//-----------------del------------------
	public function deleteaud($uid)
	{
	$this->load->model('ManageAuds_Model');
	$this->ManageAuds_Model->deleteaud($uid);
	$this->session->set_flashdata('success', 'Аудитория успешно удалена!');
	redirect('admin/manage_auds');
	}
}