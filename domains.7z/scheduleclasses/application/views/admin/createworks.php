<!DOCTYPE html>
<html lang="en">
<head>
<title>ЛК пользователя-добавить расписание</title>
<!-- Bootstrap core CSS-->
<?php echo link_tag('assests/vendor/bootstrap/css/bootstrap.min.css'); ?>
<!-- Custom fonts for this template-->
<?php echo link_tag('assests/vendor/fontawesome-free/css/all.min.css'); ?>
<!-- Page level plugin CSS-->
<?php echo link_tag('assests/vendor/datatables/dataTables.bootstrap4.css'); ?>
<!-- Custom styles for this template-->
<?php echo link_tag('assests/css/sb-admin.css'); ?>
  </head>
  <body id="page-top">
   <?php include APPPATH.'views/admin/includes/header.php';?>
   <div id="wrapper">
   <!-- Sidebar -->
  <?php include APPPATH.'views/admin/includes/sidebar.php';?>
  <div id="content-wrapper">
       <div class="container-fluid">
          <!-- Breadcrumbs-->
         <ol class="breadcrumb">
           <li class="breadcrumb-item">
           <a href="<?php echo site_url('admin/Manage_Works'); ?>">Расписание</a>
            </li>
            <li class="breadcrumb-item active">Добавить расписание</li>
          </ol>
          <!-- Page Content -->
          <h1>Добавить расписание</h1>
          <hr>
		<!---- Success Message ---->
		<?php if ($this->session->flashdata('success')) { ?>
		<p style="color:green; font-size:18px;"><?php echo $this->session->flashdata('success'); ?></p>
		</div>
		<?php } ?>
		<!---- Error Message ---->
		<?php if ($this->session->flashdata('error')) { ?>
		<p style="color:red; font-size:18px;"><?php echo $this->session->flashdata('error');?></p>
		<?php } ?> 

		 <form action="<?php echo base_url('admin/Manage_Works/createworks') ?>" method="post">
		  
		  <!-- ---------------dow--------------------------------------- -->
			<div class="form-group has-feedback">
				<select class="form-control" id="dow_id" name="dow_id" required="true">
				<option value="">Выберите день недели</option>
				  <?php 
				  foreach ($dowsdetails as $row): ?>
						  
						  <option value="<?php echo $row->id; ?>"><?php echo $row->dow; ?></option>
				  <?php endforeach ?>
				</select>
			  </div>
			<!-- ---------------time--------------------------------------- -->
			<div class="form-group has-feedback">
				<select class="form-control" id="time_id" name="time_id" required="true">
				<option value="">Выберите время</option>
				  <?php 
				  foreach ($timesdetails as $row): ?>
						  
						  <option value="<?php echo $row->id; ?>"><?php echo $row->timew; ?></option>
				  <?php endforeach ?>
				</select>
			  </div>
			<!-- ------------------------------------------------------------- -->
			<div class="form-group has-feedback">
			<input type="text" class="form-control" name="name" id="name" placeholder="Предмет" autocomplete="off" required="">
			<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
		    </div>
			<!-- ---------------group_id--------------------------------------- -->
			<div class="form-group has-feedback">
				<select class="form-control" id="group_id" name="group_id" required="true">
				<option value="">Выберите группу</option>
				  <?php 
				  foreach ($groupsdetails as $row): ?>
						  
						  <option value="<?php echo $row->id; ?>"><?php echo $row->name; ?></option>
				  <?php endforeach ?>
				</select>
			  </div>
			<!-- ---------------aud_id--------------------------------------- -->
			<div class="form-group has-feedback">
				<select class="form-control" id="aud_id" name="aud_id" required="true">
				<option value="">Выберите аудиторию</option>
				  <?php 
				  foreach ($audsdetails as $row): ?>
						  
						  <option value="<?php echo $row->id; ?>"><?php echo $row->num; ?></option>
				  <?php endforeach ?>
				</select>
			  </div>
			<!-- ---------------prepod_id--------------------------------------- -->
			<div class="form-group has-feedback">
				<select class="form-control" id="prepod_id" name="prepod_id" required="true">
				<option value="">Выберите преподавателя</option>
				  <?php 
				  foreach ($prepodsdetails as $row): ?>
						  
						  <option value="<?php echo $row->id; ?>"><?php echo $row->fio; ?></option>
				  <?php endforeach ?>
				</select>
			  </div>
			<!-- ------------------------------------------------------------- -->
		  <div class="form-group has-feedback">
     		<div class="col-xs-8">
			  <button type="submit" class="btn btn-primary btn-block btn-flat">Добавить</button>
			</div>
		  </div>
		</form>
  </div>
  <!-- /.container-fluid -->
  <!-- Sticky Footer -->
  <?php include APPPATH.'views/admin/includes/footer.php';?>
  </div>
  <!-- /.content-wrapper -->
  <!-- /#wrapper -->
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
  </a>
  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url('assests/vendor/jquery/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assests/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url('assests/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>
  <!-- Custom scripts for all pages-->
  <script src="<?php echo base_url('assests/js/sb-admin.min.js '); ?>"></script>
 </body>
</html>